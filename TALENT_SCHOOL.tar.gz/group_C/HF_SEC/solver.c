#include <stdio.h>
#include <math.h>
#include "solver.h"
#include "param.h"
#include "check.h"
#include "eigen.h"
#include "sho.h"
#include "potential.h"
#define EPS 1e-12
#define MAXITN 50

int N_all; // dimension of the base space
const int N_shell = 12; // osc shells
// sets the diagonal matrix N_all x N_all with
// 1 on the first N_occ diagonal elements
// 0 elsewhere

void rho_distribution(rjl *rho, int maxi, int N_occ, double hw)
{
int i, j, n;
double sum, mw, part, rms_sum = 0.0;
double r1;
FILE *fp;
double sum1, total = 0.0, total2 = 0.0;
mw = hw / H2M;
fp = fopen("rho_r.dat", "w+");
for (r1 = 0.01; r1 <= 10.0; r1 += 0.01){
	total = 0.0;
     for (n = 0; n < maxi; n ++){
	sum = 0.0;
	
		for (i = 0; i < rho[n].nmax; i++){
			for (j = 0; j < rho[n].nmax; j++){
		part = sho_wf(r1, mw, i, rho[n].L)*sho_wf(r1, mw, j, rho[n].L)*rho[n].r[i][j];
		sum += part;} 
		}//end of i j sumation
	sum *= rho[n].deg; //deg of rho depending on number of particles
	total += sum;
	}//end of n
total2 += total*r1*r1;
rms_sum += total*r1*r1*r1*r1;
fprintf (fp, "%e %e\n", r1, total*r1*r1/N_occ);

}	
printf ("Check total N = %e\n", total2*0.01);
printf ("RMS RADIUS = %e\n", sqrt(rms_sum*0.01/N_occ));
//printf ("Check total N = %e", total2/4.0/3.14);
fclose(fp);
}

rjl *create_rjl(int N_dif, int *nr, int *N_occ, int *deg, int *L, int *js){
int i, j, k;
rjl *temp;

 if (N_shell <= 0) {
    fprintf(stderr, "create_rjl: creation of Vab zero size (no allocation)\n");
    exit(1);
  }  

  temp = (rjl*) malloc((N_dif)*sizeof(rjl));
for (k = 0; k < N_dif; k++)
	{
	//temp[i].r = alloc_matrix((int)index[i], (int)index[i]);
	temp[k].r = alloc_matrix((nr[k]+1), (nr[k]+1));
	for (i = 0; i < nr[k]; i++) 
		{
		for (j = 0; j < i; j++)
	      	temp[k].r[j][i] = temp[k].r[i][j] = 0.;
	        temp[k].r[i][i] = (i < N_occ[k]) ? 1. : 0.;
  		}
	temp[k].nmax = nr[k]+1;
	temp[k].i = k;
	temp[k].occ = N_occ[k];
	temp[k].deg = deg[k];
	temp[k].L = L[k];
	temp[k].js = js[k];
	//if (k % 2 == 0)
	//temp[k].j = 
	}
return temp; 

}




//change void by integer and return maxi.
void set_rjl_V(int N_occ, double hw){
int n_max, l, N_count;//n_max dimension of matrix
int i, ind, j, *js;
int *index;
int maxi;
int *nr;
int *nr_temp, *deg, *L;
int occ = 0, tot_occ = 0;
int dim = 0;
Vf *Vacbd;
ind = 0; occ = 2; maxi = 0;
rjl *rho_jl;
double E, E_old;
es_t *hamilt;
double trace;
E_old = 1.;
E = 0.;

index = (int*)malloc((N_shell+1)*sizeof(int));
nr_temp = (int*)malloc((N_shell+1)*sizeof(int));
deg = (int*)malloc((N_shell+1)*sizeof(int));
L = (int*)malloc((N_shell+1)*sizeof(int));
js = (int*)malloc((N_shell+1)*sizeof(int));
for (i = 0; i <= N_shell; i++) {index[i] = 0.0; nr_temp[i] = 0;}

printf ("Total number of particles = %d\n", N_occ);
for (N_count = 0; N_count <= N_shell; N_count++)
{
printf ("----------------- N = %d -------------------\n", N_count);

for (l = N_count; l >= 0; l=l-2)
	{
//	if (ind > ending) ind = 0;
	n_max = (N_shell-l)/2;
//	n_max = (N_shell+N_count-l)/2;
//	printf ("N_shell = %d N_count = %d l = %d n_max = %d\n", N_shell, N_count, l, n_max);
	for (i = 0; i <= 1; i++)
		{ 
		if (i == 0)
			{
			j = 2*l+1;
			occ = (j+1);//spin up and down
			tot_occ += occ;//l +1/2 
			if (tot_occ <= N_occ)
				{
				printf("particles --> %d\n", occ);
				printf ("%d) N_shell = %d occ n_dim = %d l = %d j = %d/2\n", dim, N_count, n_max+1, l, j);
				if (l == 0) {index[0] += 1;
					if (nr_temp[0] < n_max) nr_temp[0] = n_max;// nr[0] = n_max;
deg[0] = occ; L[0] = l; js[0] = j;}
				else
					{
					index[2*l-1] += 1;
					deg[2*l-1] = occ; L[2*l-1] = l;
					js [2*l-1] = j;
					if (nr_temp[2*l-1] < n_max) nr_temp[2*l-1] = n_max;
					if (maxi < 2*l-1) maxi = 2*l-1;
					}
				dim++;
				}
			else break;	
			}
		else if (i == 1 && l != 0)
			{
			j = 2*l-1;//l -1/2
			occ = (j+1);//spin up and down
			tot_occ += occ;
			if (tot_occ <= N_occ)
				{
				printf("particles --> %d\n", occ);
				printf ("%d) N_shell = %d occ n_dim = %d l = %d j = %d/2\n", dim, N_count, n_max+1, l, j);
				index[2*l] += 1; //nr[2*l] = n_max;
				deg[2*l] = occ;
				L[2*l] = l;
				js[2*l] = j;
				if (maxi < 2*l) maxi = 2*l;
				if (nr_temp[2*l] < n_max) nr_temp[2*l] = n_max;				
				dim++;
				}
			else break;	
			}
		//else printf ("## noc l = %d j = %d\n", dim, l, j); 
		
		}
	}
//*max = maxi; 
//return nr;
}
//dim--;
printf ("Number of subshells occupied = %d\n", dim);
maxi++;
//change dimension by index of different l or j
nr = (int*)malloc((maxi)*sizeof(int));
for (i = 0; i < maxi; i++) {nr[i] = nr_temp[i]; printf("nr[%d]= %d\n", i, nr[i]);}
rho_jl = create_rjl(maxi, nr, index, deg, L, js);

for (i = 0; i < maxi; i++) 
	{
	//printf ("Rho matrix[%d] = %d\n", i, index[i]);
	printf("\n");
	printf ("N_occ[%d] = %d\n", i, rho_jl[i].deg*rho_jl[i].occ);
	printf ("L = %d J = %d\n", rho_jl[i].L, rho_jl[i].js);
	print_rho (rho_jl[i].r, rho_jl[i].nmax);
	printf("\n");	
	}
printf ("Creating V\n");
Vacbd = create_V(nr, maxi, hw);
printf ("Calculating V\n");
V_me(Vacbd, rho_jl, hw, maxi);
printf ("Create H\n");
hamilt = createH(nr, maxi);
printf ("Set H\n");
//make_hamilt(hamilt, rho_jl, Vacbd, maxi);
//printf ("Solve eigvalue eq...\n");
i = 0;
while (fabs(E - E_old) > EPS && i < MAXITN)
{
//printf ("Make Hamilt\n");
make_hamilt(hamilt, rho_jl, Vacbd, maxi);
//printf ("Solve eig\n");
solve_eigs(hamilt, maxi);
//printf ("Calc_rhos\n");
calc_rhos(hamilt, rho_jl, maxi);
E_old = E;
trace = 0.0;
    E = calc_E(hamilt, rho_jl, Vacbd, maxi);
	for (j = 0; j < maxi; j++) trace += check_rho(rho_jl[j].r, rho_jl[j].nmax)*rho_jl[j].deg;
    printf("Trace = %e ! Finished iteration %d: E = %f\n", trace, i, E);
    i++;
}

rho_distribution(rho_jl, maxi, N_occ, hw);
return;
}

void make_hamilt(es_t *hamilt, rjl *rho, Vf *V, int maxi)
{
  int a, b, c, d, jl1, jl2;
for (jl1 = 0; jl1 < maxi; jl1++){
  for (a = 0; a < rho[jl1].nmax; a++) {
    for (b = 0; b <= a; b++) {
      hamilt[jl1].eig.a[a][b] = V[jl1].T[a][b];
      for (jl2 = 0; jl2 < maxi; jl2++){
      	for (c = 0; c < rho[jl2].nmax; c++) {
      	  for (d = 0; d < rho[jl2].nmax; d++){
          hamilt[jl1].eig.a[a][b] += V[jl1].Vab[a][b].Vab[jl2].V_cd[c][d] * rho[jl2].r[c][d];	}
      	}
      }
      hamilt[jl1].eig.a[b][a] = hamilt[jl1].eig.a[a][b];
    }
  }
}

return;
}


//this function calculates all rhos
void calc_rhos(es_t *hamilt, rjl *rho, int maxi){
int i, j, k, jl;
for (jl = 0; jl < maxi; jl++)
	{
	for (i = 0; i < rho[jl].nmax; i++) {
    		for (j = 0; j < rho[jl].nmax; j++) {
      		rho[jl].r[i][j] = 0.0;
      		for (k = 0; k < rho[jl].occ; k++)
        		rho[jl].r[i][j] += hamilt[jl].eig.eigvec[i][k]*hamilt[jl].eig.eigvec[j][k];
		//this part must be added
    			}
  		}
	}	

return;
}

// calculates the total energy from the first N_occ eigenvalues from hamilt
// and from Vacbd[a][b].t times the density matrix rho[a][b]
double calc_E(es_t *hamilt, rjl *rho, Vf *Vacbd, int maxi)
{
  int i, j, jl;
  double E;
E = 0.0;
//whait
for (jl = 0; jl < maxi; jl ++)
{
  for (i = 0; i < rho[jl].occ; i++)
    E += hamilt[jl].eig.lam[i]*rho[jl].deg;//multiplied by number of particles with different m (degeneracy)
  for (i = 0; i < rho[jl].nmax; i++) {
    for (j = 0; j < rho[jl].nmax; j++)
      E += Vacbd[jl].T[i][j] * rho[jl].r[i][j]*rho[jl].deg;
//simple form in Ring (5.29), (5.37), (5.40)
  }

}
  return 0.5 * E;//there is no extra 2.0 factor
}


es_t *createH(int *nr, int maxi){
es_t *temp;//1d array dimension maxi (different matrices rho)
int i;
 if (maxi <= 0) {
    fprintf(stderr, "create_Vf: creation of Vf zero size (no allocation)\n");
    exit(1);
  }  
temp = (es_t*)malloc((maxi)*sizeof(es_t));
for (i = 0; i < maxi; i++)
	{
	temp[i].eig = alloc_eig(nr[i]+1);
	}
return temp;
}

/*
eig_t *solve_HF(Vf **Vacbd, int N_occ)
{
  int i = 0;
  double E, E_old, **rho;
  eig_t hamilt;
  rjl *rho_lj;
  N_all = N_dim;
  hamilt = alloc_eig(N_all); // eigen.c
  rho = init_rho(N_occ);
  E_old = 1.;
  E = 0.;
  set_rjl(80, rho_lj);
  while (fabs(E - E_old) > EPS && i < MAXITN) {
    make_hamilt(hamilt, rho, Vacbd);
    solve_eig(hamilt); // eigen.c
    calc_rho(hamilt, rho, N_occ);
//	check_rho(rho, N_all);
    E_old = E;
    E = calc_E(hamilt, rho, Vacbd, N_occ);
    printf("iteration %d: E = %f\n", i, E);
    i++;
  }
  printf("E = %lf, ", E);
  for (i = 0; i < N_occ - 1; i++)
    printf("e%d = %lf, ", i+1, hamilt.lam[i]);
  printf("e%d = %lf\n", N_occ, hamilt.lam[N_occ-1]);
//  free(rho[0]); free(rho);
  return hamilt;
}
*/
/*
eig_t solve_HF(Vab_t **Vacbd, int N_dim, int N_occ)
{
  int i = 0;
  double E, E_old, **rho;
  eig_t hamilt;
  rjl *rho_lj;
  N_all = N_dim;
  hamilt = alloc_eig(N_all); // eigen.c
  rho = init_rho(N_occ);
  E_old = 1.;
  E = 0.;
  set_rjl(80, rho_lj);
  while (fabs(E - E_old) > EPS && i < MAXITN) {
    make_hamilt(hamilt, rho, Vacbd);
    solve_eig(hamilt); // eigen.c
    calc_rho(hamilt, rho, N_occ);
//	check_rho(rho, N_all);
    E_old = E;
    E = calc_E(hamilt, rho, Vacbd, N_occ);
    printf("iteration %d: E = %f\n", i, E);
    i++;
  }
  printf("E = %lf, ", E);
  for (i = 0; i < N_occ - 1; i++)
    printf("e%d = %lf, ", i+1, hamilt.lam[i]);
  printf("e%d = %lf\n", N_occ, hamilt.lam[N_occ-1]);
//  free(rho[0]); free(rho);
  return hamilt;
}*/
