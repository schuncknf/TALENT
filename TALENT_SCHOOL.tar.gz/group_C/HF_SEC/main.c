#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include "solver.h"
#include "param.h"
#include "potential.h"
#include "sho.h"

int main(int argc, char *argv[])
{
clock_t begin, end;
double time_spent;

begin = clock();
/* here, do your time-consuming job */

  int Nocc; //occupation number
  double hw; // hw = h*omega; the units: h = m = 1
  double mw;
  int maxi = 0, i, *nr;
 // Vf *Vacbd;
	//Vs_t *integral;
  //eig_t *HF_wf;
  //rjl *rho;
  // matrix dimension: the maximum n quantum number (l=0 in this program)
  if (argc != 3) {
    printf("Usage: ./run hw Nocc\n ");
    return 1;
  }
  hw = atof(argv[1]);
  //N = atoi(argv[2]) + 1;
  Nocc = atoi(argv[2]);
  set_rjl_V(Nocc, hw);
 
end = clock();
time_spent = (double)(end - begin) / CLOCKS_PER_SEC;
printf ("\nRUNNING TIME = %lf\n", time_spent);
  return  0;
}

void write_V(int *nr, int maxi, double mw, Vf *V){
//integral = create_Vs (nr, maxi);
char file_name2[10];
FILE *fp;
int i,j,jl;
sprintf(file_name2, "Vjl%d.bin", jl);
if((fp=fopen(file_name2, "wb"))==NULL) {
    printf("Cannot open file.\n");
}
//if(fwrite(floatValue, sizeof(double), 5, fp) != 5)

return;
}
