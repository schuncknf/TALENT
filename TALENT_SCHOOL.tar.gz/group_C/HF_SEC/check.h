#ifndef _check_h
#define _check_h

//void check_rho(double **, int N);
void print_rho(double **, int N);
double check_rho(double **, int N);
#endif
