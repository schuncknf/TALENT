#ifndef _potential_h
#define _potential_h

double T_me(double hw, int n1, int n2, int l);
//double **V_pot(int a, int b, int c, int d, double hw);
double **V_pot(int a, int b, double hw, int N);

#endif
