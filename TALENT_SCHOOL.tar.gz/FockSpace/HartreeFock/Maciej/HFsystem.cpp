//HF system

#include <iostream>
#include <fstream>
#include <cmath>
#include <armadillo>

using namespace std;
using namespace arma;

void DensityMatrix(mat D,mat eigenvec,int N){
	return;
}

void SingleParticleHamiltonian(mat H,mat eigenvec,int N){
	return;
}
