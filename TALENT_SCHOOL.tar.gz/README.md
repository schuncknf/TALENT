TALENT
======

Public repository containing student's computational projects
