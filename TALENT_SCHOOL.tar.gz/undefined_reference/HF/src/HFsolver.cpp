#include "HFsolver.hpp"


void HartreeFock::run( Hamiltonian* h){
	// implementation of the HF solver routine goes here
	// use h.oneBodyPart or h.twoBodyPart
	;
}
