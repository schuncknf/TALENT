void spindiagonalizeascending(vec& eigval, mat& eigvec,mat& obdens,imat& spbasis);
void spindiagonalizedescending(vec& eigval, mat& eigvec,mat& obdens,imat& spbasis);


