double onebody(int i1,int j2,imat spbasis,double data[]);
double tbmewfintegrandinf(double r1,double r2, double data[]);
double twobody(int i1,int j2,int k3,int m4,imat spbasis,double data[]);
