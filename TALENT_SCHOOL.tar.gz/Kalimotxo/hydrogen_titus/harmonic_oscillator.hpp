double ho_radialtalent (double r, double data[]);
