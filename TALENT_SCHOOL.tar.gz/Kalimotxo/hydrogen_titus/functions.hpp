double kinetic(int nx,int ny,double b);
double wfintegrand(double r, double data[]);
double meintegrand(double r, double data[]);
double tbme(int n1,int n2,double b);
double meintegrandinf(double r, double data[]);
double tbmeinf(int n1,int n2,double b);
double wfintegrandinf(double r, double data[]);
