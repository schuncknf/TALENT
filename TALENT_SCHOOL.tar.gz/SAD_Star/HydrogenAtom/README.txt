HYDROGEN ATOM
-) To run the program just type "make" on the terminal;
-) The result is a file called "HydrogenAtom_Benchmark.txt" and nothing will be print on video; the file contains the benchmark calculation with data written in the required disposition.
-) The integration has been done using the function GSL library, with the Gauss-Legendre fixed node method. 