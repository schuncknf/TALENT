valgrind --tool=callgrind ./testMain --run_test=vMinnesotaMatrixGenerator
